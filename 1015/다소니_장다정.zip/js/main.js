$(function(){

    // 처음 시작할 때부터 글자 슬라이드 적용하기 위해
    setTimeout(function(){
        $('.slider li .text0').addClass('on');
        $('.slider li .atext0').addClass('on');

    },500);

    let bx = $('.slider').bxSlider({
        auto:true,
        controls:false,
        pager:false,
        mode:'fade',
        pause:5000,
        onSlideBefore:function(){

        },
        onSlideAfter:function(){
            let k = bx.getCurrentSlide();  //현재 슬라이드 번호
            $('.slider li').find('h2').removeClass('on');
            $('.slider li').find('p').removeClass('on');
            $('.slider li .text'+k).addClass('on');
            $('.slider li .atext'+k).addClass('on');
        },
    });

    let a1 = $('.s2_title img').offset().top;
    let b1 = $('.s4_title img').offset().top;
    //이미지
    let a2 = $('.s2_title h2').offset().top;
    let b2 = $('.s4_title h2').offset().top;
    //제목
    let a3 = $('.s2_title p').offset().top;
    let b3 = $('.s4_title p').offset().top;
    // 내용
    let a4 = $('.s2_table li').offset().top;
    let b4 = $('.s4_table li').offset().top;
    console.log(a1,a2,a3,a4);
    console.log(b1,b2,b3,b4);
    
    let c = $('.s5_inner').offset().top;
    let d = $('.s6_content').offset().top;
    let f = $('.fix_box').offset().top;
    
    
    $(window).scroll(function(){
        let sct = $(this).scrollTop();
        $('.fix_box').stop().animate({top:f+sct},500)

        if(a1 <= sct + 700){
            $('.s2_title img').addClass('slide');
        }
        if(a2 <= sct + 700){
            $('.s2_title h2').addClass('slide');
        }
        if(a3 <= sct + 700){
            $('.s2_title p').addClass('slide');
        }
        if(a4 <= sct + 700){
            $('.s2_table li').eq(0).addClass('slide');
            
            setTimeout(function(){
                $('.s2_table li').eq(1).addClass('slide');
            },300)
            setTimeout(function(){
                $('.s2_table li').eq(2).addClass('slide');
            },600)
            setTimeout(function(){
                $('.s2_table li').eq(3).addClass('slide');
            },900)
        }


        if(b1 <= sct + 700){
            $('.s4_title img').addClass('slide');
        }
        if(b2 <= sct + 700){
            $('.s4_title h2').addClass('slide');
        }
        if(b3 <= sct + 700){
            $('.s4_title p').addClass('slide');
        }
        if(b4 <= sct + 700){
            $('.s4_table li').eq(0).addClass('slide');
            
            setTimeout(function(){
                $('.s4_table li').eq(1).addClass('slide');
            },300)
            setTimeout(function(){
                $('.s4_table li').eq(2).addClass('slide');
            },600)
            setTimeout(function(){
                $('.s4_table li').eq(3).addClass('slide');
            },900)
        }

        if(c <= sct + 500){
            $('.s5_inner').addClass('slide1');
        }
        if(d <= sct + 500){
            $('.s6_content').addClass('slide1');
        }
    });
});